﻿' Name:         Net Project
' Purpose:      Displays net income or loss
' Programmer:   Zachary Murphy on 2-16-2017

Option Explicit On
Option Infer Off
Option Strict On

Public Class frmMain
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' calculate net income or net loss

        Dim decIncome As Decimal
        Dim decExpenses As Decimal
        Dim decNet As Decimal

        Decimal.TryParse(txtIncome.Text, decIncome)
        Decimal.TryParse(txtExpenses.Text, decExpenses)

        decNet = decIncome - decExpenses
        'if statement for the color of text dependent on result
        If decNet < 0 Then
            lblNet.ForeColor = Color.Red
        Else
            lblNet.ForeColor = Color.Black
        End If

        lblNet.Text = decNet.ToString("c2")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub ClearNet(sender As Object, e As EventArgs) Handles txtIncome.TextChanged, txtExpenses.TextChanged
        lblNet.Text = String.Empty
    End Sub
End Class
